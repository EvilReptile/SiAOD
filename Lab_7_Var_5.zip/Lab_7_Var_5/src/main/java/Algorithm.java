public abstract class Algorithm {

    public abstract void findPath(Location start, Location end, JMap[][] map);
    public abstract String toString();
    public abstract void clean();
}
