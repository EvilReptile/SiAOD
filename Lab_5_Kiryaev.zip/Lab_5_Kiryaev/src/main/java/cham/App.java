package cham;

import java.awt.*;

public class App {
    public static void main( String[] args ) {
        GUI gui = new GUI(new Dimension(1000, 1000));
    }
}
